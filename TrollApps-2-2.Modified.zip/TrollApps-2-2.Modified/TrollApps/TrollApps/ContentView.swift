//
//  ContentView.swift
//  TrollApps
//
//  Created by Анохин Юрий on 11.11.2022.
//

import SwiftUI

struct ContentView: View {
    @State private var selectedTab = 0

    @State private var selectedAppIndex = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {

            AppsView()
                .tabItem {
                    Label("Apps", systemImage: "app.badge.checkmark")
                }
                .tag(2)
            SourcesView()
                .tabItem {
                    Label("Repos", systemImage: "globe.americas.fill")
                }
                .tag(1)
            FeaturedView()
                 .tabItem {
                     Label("Featured", systemImage: "star.fill")
                 }
                 .tag(0)

            OtherView()
                .tabItem {
                    Image(systemName: "gearshape")
                    Text("Settings")
                }
                .tag(3)
        }
        .onOpenURL { url in
            selectedTab = 0
        }
    }
}



