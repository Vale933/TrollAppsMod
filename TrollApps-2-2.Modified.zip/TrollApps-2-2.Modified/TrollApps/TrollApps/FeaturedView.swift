//
//  FeaturedView.swift
//  TrollApps
//
//  Created by Анохин Юрий on 21.11.2022.
//

import SwiftUI
import SDWebImageSwiftUI

struct BubbleView: View {
    var body: some View {
        GeometryReader { geo in
            ForEach(0..<10, id: \.self) { index in
                Circle()
                    .fill(randomColor(index: index))
                    .frame(width: randomSize(), height: randomSize())
                    .position(x: CGFloat.random(in: 0...geo.size.width),
                              y: CGFloat.random(in: 0...geo.size.height))
            }
        }
    }

    private func randomSize() -> CGFloat {
        CGFloat.random(in: 10...100)
    }

    private func randomColor(index: Int) -> Color {
        Color(hue: Double(index) / 10, saturation: 1, brightness: 1)
    }
}

struct FeaturedView: View {
    @EnvironmentObject var repoManager: RepositoryManager
    @State private var featuredApps: [Application] = []
    @State private var errorMessage = ""
    @State private var isRefreshing = false
    @State private var dragOffset: CGFloat = 0

    var body: some View {
        ZStack {
            BubbleView()
                .zIndex(0)

            NavigationView {
                List {
                    if featuredApps.isEmpty {
                        EmptyListView(message: "No featured apps found.")
                    } else {
                        Section(header: Text("Featured Apps (\(featuredApps.count))")) {
                            ForEach(featuredApps, id: \.id) { app in
                                FeaturedAppRow(app: app)
                            }
                        }
                        .listRowInsets(EdgeInsets(top: 15, leading: 15, bottom: 15, trailing: 20))
                        .environment(\.defaultMinListRowHeight, 50)
                    }
                }
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            if value.translation.height > 0 && value.translation.height > dragOffset {
                                dragOffset = value.translation.height
                            }
                        }
                        .onEnded { value in
                            if dragOffset > 50 {
                                refreshFeaturedApps()
                            }
                            dragOffset = 0
                        }
                )
                .overlay(
                    VStack {
                        if isRefreshing {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .blue))
                                .padding(.vertical, 10)
                        }
                        Text(isRefreshing ? "Refreshing..." : "")
                            .foregroundColor(.gray)
                            .font(.caption)
                    }
                    .frame(maxWidth: .infinity, alignment: .center)
                )
                .navigationTitle("Featured")
                .alert(isPresented: .constant(!errorMessage.isEmpty)) {
                    Alert(
                        title: Text("Error"),
                        message: Text(errorMessage),
                        dismissButton: .default(Text("OK"))
                    )
                }
            }
            .onAppear {
                if !repoManager.hasFetchedRepos {
                    repoManager.fetchRepos()
                }
                refreshFeaturedApps()
            }
            .zIndex(1)
        }
    }
    private func refreshFeaturedApps() {
        if isRefreshing {
            return
        }
        isRefreshing = true
        featuredApps.removeAll()

        for repo in repoManager.ReposData {
            if let featuredAppsInRepo = repo.data.featuredApps {
                for featuredAppBundleId in featuredAppsInRepo {
                    if let app = repo.data.apps.first(where: { $0.bundleIdentifier == featuredAppBundleId }) {
                        featuredApps.append(app)
                    }
                }
            }
        }

        isRefreshing = false

        if featuredApps.isEmpty {
            errorMessage = "No featured apps found."
        }
    }
}

struct FeaturedAppRow: View {
    let app: Application

    var body: some View {
        NavigationLink(destination: AppDetailsView(appDetails: app)) {
            HStack {
                WebImage(url: URL(string: app.iconURL ?? ""))
                    .resizable()
                    .frame(width: 30, height: 30)
                    .clipShape(RoundedRectangle(cornerRadius: 7))
                    
                Text(app.name)
            }
        }
    }
}

struct EmptyListView: View {
    let message: String

    var body: some View {
        VStack {
            Text(message)
                .foregroundColor(.gray)
                .font(.title)
                .padding()
        }
    }
}
