import SwiftUI
import SDWebImageSwiftUI

struct AppsView: View {
    @EnvironmentObject var repoManager: RepositoryManager
    @State private var searchText = ""

    func commonView() -> some View {
        List(filteredApps) { app in
            HStack {
 //               WebImage(url: URL(string: app.iconURL))
   //                 .resizable()
    //                .frame(width: 30, height: 30)
      //              .clipShape(RoundedRectangle(cornerRadius: 7))
                VStack(alignment: .leading) {
                    Text(app.name)
                    Text("\(app.id)")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
        }
        .environment(\.defaultMinListRowHeight, 50)
        .listStyle(PlainListStyle())
        .navigationTitle("Installed Apps")
    }

    var body: some View {
        VStack {
            if #available(iOS 15.0, *) {
                commonView()
                    .searchable(text: $searchText)
            } else {
                SearchBar(searchText: $searchText)
                commonView()
            }
        }
        .navigationTitle("Installed Apps")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    var filteredApps: [BundledApp] {
        return searchText.isEmpty ? repoManager.InstalledApps : repoManager.InstalledApps.filter { app in
            app.isTrollStore == true && app.name.localizedCaseInsensitiveContains(searchText)
        }
    }
}


